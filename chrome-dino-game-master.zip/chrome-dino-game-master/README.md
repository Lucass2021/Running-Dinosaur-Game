# chrome-dino-game

[YouTube Tutorial Video](https://youtu.be/4Oz34co7VLY)

Making the chrome dinosour (no internet connection) game.

![Screenshot 2020-11-08 at 14 47 06](https://user-images.githubusercontent.com/17026751/98468228-6f0df800-21d1-11eb-94f2-034a5f610145.png)
